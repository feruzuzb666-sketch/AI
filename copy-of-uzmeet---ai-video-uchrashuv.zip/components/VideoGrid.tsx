import React, { useEffect, useRef, useState } from 'react';

interface VideoGridProps {
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  aiVolume: number; // New prop: 0 to 1
  isAIConnected: boolean; // To distinguish between Human vs AI
  caption: string; // New prop for subtitles
}

export const VideoGrid: React.FC<VideoGridProps> = ({ 
  localStream, 
  remoteStream, 
  aiVolume,
  isAIConnected,
  caption
}) => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  
  // Blink animation state
  const [isBlinking, setIsBlinking] = useState(false);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  // Random blinking logic for AI
  useEffect(() => {
    if (!isAIConnected) return;
    
    const blinkInterval = setInterval(() => {
        setIsBlinking(true);
        setTimeout(() => setIsBlinking(false), 200);
    }, 4000 + Math.random() * 2000); // Blink every 4-6 seconds

    return () => clearInterval(blinkInterval);
  }, [isAIConnected]);

  // Derived state for visualizer
  const isActive = aiVolume > 0.05;

  return (
    <div className="flex-1 p-4 flex flex-col md:flex-row gap-4 h-[calc(100vh-80px)] overflow-y-auto">
      {/* Remote Participant (AI or Human) */}
      <div className="flex-1 bg-gray-900 rounded-2xl overflow-hidden relative border border-gray-800 flex items-center justify-center min-h-[300px] shadow-2xl">
        
        {/* Status Badge */}
        <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-sm font-medium z-10 flex items-center gap-2 border border-white/10">
          {isAIConnected ? (
             <>
               <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_#3b82f6]"></span>
               <span className="text-blue-200 font-mono tracking-wide">GEMINI LIVE</span>
             </>
          ) : remoteStream ? (
             <>
               <span className="w-2 h-2 bg-green-500 rounded-full"></span>
               Mehmon
             </>
          ) : (
             <span className="text-gray-400">Kutilmoqda...</span>
          )}
        </div>
        
        {/* Scenario 1: Real Human Video */}
        {remoteStream && !isAIConnected && (
            <video 
                ref={remoteVideoRef}
                autoPlay 
                playsInline 
                className="w-full h-full object-cover" 
            />
        )}

        {/* Scenario 2: AI Digital Avatar (Improved) */}
        {isAIConnected && (
            <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-[#0f172a] to-black flex items-center justify-center overflow-hidden">
                {/* Background Grid Effect */}
                <div className="absolute inset-0 opacity-20" 
                     style={{ 
                         backgroundImage: 'radial-gradient(#4f46e5 1px, transparent 1px)', 
                         backgroundSize: '40px 40px' 
                     }}>
                </div>
                
                {/* Ambient Glow */}
                <div 
                    className="absolute w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[100px] transition-all duration-75"
                    style={{ 
                        opacity: 0.3 + (aiVolume * 0.7),
                        transform: `scale(${1 + aiVolume * 0.2})`
                    }}
                ></div>

                {/* The Avatar Head */}
                <div 
                    className="relative z-10 transition-transform duration-75"
                    style={{ transform: `scale(${1 + aiVolume * 0.05})` }}
                >
                    <div className="w-48 h-56 bg-gradient-to-br from-slate-800 to-black rounded-[3rem] border border-slate-700/50 shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col items-center justify-center relative p-6 backdrop-blur-xl">
                        
                        {/* Metallic/Glass Shine */}
                        <div className="absolute top-0 inset-x-0 h-1/2 bg-gradient-to-b from-white/5 to-transparent rounded-t-[3rem]"></div>

                        {/* Eyes Container */}
                        <div className="flex gap-8 mb-8 w-full justify-center">
                           {/* Left Eye */}
                           <div className={`w-12 h-8 bg-black rounded-full flex items-center justify-center relative overflow-hidden transition-all duration-100 ${isBlinking ? 'h-1' : 'h-8'}`}>
                              <div className="w-3 h-3 bg-blue-400 rounded-full shadow-[0_0_15px_#60a5fa] animate-pulse"></div>
                           </div>
                           {/* Right Eye */}
                           <div className={`w-12 h-8 bg-black rounded-full flex items-center justify-center relative overflow-hidden transition-all duration-100 ${isBlinking ? 'h-1' : 'h-8'}`}>
                              <div className="w-3 h-3 bg-blue-400 rounded-full shadow-[0_0_15px_#60a5fa] animate-pulse"></div>
                           </div>
                        </div>

                        {/* Mouth / Voice Interface */}
                        <div className="h-12 flex items-center justify-center relative">
                            {/* Visual representation of mouth that reacts to audio */}
                            <div 
                                className="bg-blue-500/90 rounded-full shadow-[0_0_20px_#3b82f6] transition-all duration-0"
                                style={{
                                    width: `${32 + (aiVolume * 50)}px`,
                                    height: `${4 + (aiVolume * 30)}px`,
                                    borderRadius: aiVolume > 0.2 ? '20px' : '4px'
                                }}
                            ></div>
                        </div>
                        
                        {/* Audio Waveforms (Decoration) */}
                        {isActive && (
                            <div className="absolute -right-8 top-1/2 flex flex-col gap-1">
                                <div className="w-1 h-4 bg-blue-500/50 rounded-full animate-pulse delay-75"></div>
                                <div className="w-1 h-8 bg-blue-500/80 rounded-full animate-pulse"></div>
                                <div className="w-1 h-4 bg-blue-500/50 rounded-full animate-pulse delay-150"></div>
                            </div>
                        )}
                         {isActive && (
                            <div className="absolute -left-8 top-1/2 flex flex-col gap-1">
                                <div className="w-1 h-4 bg-blue-500/50 rounded-full animate-pulse delay-150"></div>
                                <div className="w-1 h-8 bg-blue-500/80 rounded-full animate-pulse"></div>
                                <div className="w-1 h-4 bg-blue-500/50 rounded-full animate-pulse delay-75"></div>
                            </div>
                        )}

                    </div>
                    
                    {/* Neck/Body Hint */}
                    <div className="w-24 h-12 bg-slate-900 mx-auto -mt-6 rounded-b-3xl border-x border-b border-slate-800 -z-10 relative"></div>
                </div>
            </div>
        )}

        {/* Caption Overlay (Subtitle) */}
        {caption && (
            <div className="absolute bottom-12 left-0 right-0 flex justify-center px-6 z-20">
                <div className="bg-black/80 text-white px-6 py-4 rounded-2xl text-lg text-center backdrop-blur-md shadow-2xl max-w-2xl border border-white/10 transition-all duration-300 transform translate-y-0 leading-relaxed font-medium">
                    {caption}
                </div>
            </div>
        )}

        {/* Fallback Waiting State */}
        {!remoteStream && !isAIConnected && (
             <div className="flex flex-col items-center justify-center text-gray-500 gap-4">
                <div className="w-20 h-20 rounded-full bg-gray-800 flex items-center justify-center animate-pulse">
                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                     </svg>
                </div>
                <p>Suhbatdosh kutilmoqda...</p>
                <p className="text-xs text-gray-600">Linkni ulashing</p>
             </div>
        )}
      </div>

      {/* Local User */}
      <div className="flex-1 bg-gray-900 rounded-2xl overflow-hidden relative border border-gray-800 shadow-xl">
        <div className="absolute top-4 left-4 bg-black/50 px-3 py-1 rounded-full text-sm font-medium z-10 backdrop-blur-sm">
          Siz
        </div>
        <video 
            ref={localVideoRef}
            autoPlay 
            playsInline 
            muted 
            className="w-full h-full object-cover transform -scale-x-100" 
        />
        {!localStream && (
             <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
                <span className="text-gray-500">Kamera o'chiq</span>
             </div>
        )}
      </div>
    </div>
  );
};
