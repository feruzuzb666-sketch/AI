import React, { useState, useEffect, useRef } from 'react';
import { MeetingControls } from './components/MeetingControls';
import { VideoGrid } from './components/VideoGrid';
import { ChatSidebar } from './components/ChatSidebar';
import { GeminiLiveService } from './services/geminiLiveService';
import { PeerService } from './services/peerService';
import { Message, MeetingState, User } from './types';

// --- Login Page Component ---
const LoginPage: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = () => {
    setIsLoading(true);
    // Simulate API delay
    setTimeout(() => {
        onLogin();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-brand-600/20 rounded-full blur-[120px]"></div>
      
      <div className="z-10 bg-gray-900 p-8 rounded-2xl border border-gray-800 shadow-2xl max-w-md w-full text-center space-y-8">
        <div>
            <div className="w-16 h-16 bg-brand-600 rounded-xl mx-auto flex items-center justify-center text-3xl font-bold mb-4 shadow-lg shadow-brand-600/50">U</div>
            <h1 className="text-3xl font-bold text-white mb-2">UzMeet</h1>
            <p className="text-gray-400">Video uchrashuvlar uchun tizimga kiring</p>
        </div>

        <button 
          onClick={handleGoogleLogin}
          disabled={isLoading}
          className="w-full bg-white hover:bg-gray-100 text-gray-900 font-bold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-3 relative overflow-hidden group"
        >
          {isLoading ? (
             <svg className="animate-spin h-5 w-5 text-gray-900" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
               <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
               <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
             </svg>
          ) : (
            <>
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Google orqali kirish
            </>
          )}
        </button>
      </div>
    </div>
  );
};

// --- Landing Page ---
const LandingPage: React.FC<{ onCreate: () => void; onJoin: (id: string) => void; user: User }> = ({ onCreate, onJoin, user }) => {
  const [joinInput, setJoinInput] = useState('');

  const handleJoinClick = () => {
    if (!joinInput.trim()) return;
    
    // Extract ID if a full URL is pasted
    let id = joinInput.trim();
    if (id.includes('#meeting/')) {
        id = id.split('#meeting/')[1];
    }
    // Simple cleanup if user pastes full url without hash
    if (id.includes('/')) {
        const parts = id.split('/');
        id = parts[parts.length - 1];
    }
    
    onJoin(id);
  };

  return (
  <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center relative overflow-hidden">
    <div className="absolute top-0 w-full flex justify-between items-center p-6 z-20">
        <div className="text-xl font-bold flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-600 rounded flex items-center justify-center">U</div>
            UzMeet
        </div>
        <div className="flex items-center gap-3 bg-gray-800 py-1.5 px-3 rounded-full border border-gray-700">
            <img src={user.photoUrl} alt="Avatar" className="w-8 h-8 rounded-full" />
            <span className="text-sm font-medium pr-2">{user.name}</span>
        </div>
    </div>

    <div className="z-10 text-center space-y-8 px-4 w-full max-w-2xl">
      <div className="space-y-2">
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
          Uchrashuvni Boshlash
        </h1>
        <p className="text-gray-400 text-lg md:text-xl max-w-lg mx-auto">
          Yangi uchrashuv yarating yoki do'stingiz yuborgan link orqali qo'shiling.
        </p>
      </div>

      <div className="flex flex-col items-center gap-6 mt-8 w-full max-w-md mx-auto">
        <button 
          onClick={onCreate}
          className="w-full py-4 bg-brand-600 hover:bg-brand-500 rounded-xl font-bold text-lg shadow-lg shadow-brand-600/30 transition-all transform hover:scale-105 flex items-center justify-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
             <path strokeLinecap="round" strokeLinejoin="round" d="m15.75 10.5 4.72-4.72a.75.75 0 0 1 1.28.53v11.38a.75.75 0 0 1-1.28.53l-4.72-4.72M12 18.75H4.5a2.25 2.25 0 0 1-2.25-2.25V9m12.841 9.091L16.5 19.5m-1.409-1.409c.407-.407.659-.97.659-1.591v-9a2.25 2.25 0 0 0-2.25-2.25h-9c-.621 0-1.184.252-1.591.659m12.182 12.182L2.909 5.909M1.5 4.5l1.409 1.409" />
          </svg>
          Yangi Uchrashuv Yaratish
        </button>

        <div className="flex items-center gap-4 w-full text-gray-500">
            <div className="h-px bg-gray-800 flex-1"></div>
            <span className="text-sm font-medium">YOKI</span>
            <div className="h-px bg-gray-800 flex-1"></div>
        </div>

        <div className="flex w-full gap-2">
            <input 
                type="text" 
                placeholder="Link yoki ID ni joylang" 
                value={joinInput}
                onChange={(e) => setJoinInput(e.target.value)}
                className="flex-1 bg-gray-900 border border-gray-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
            />
            <button 
                onClick={handleJoinClick}
                disabled={!joinInput.trim()}
                className="bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-white px-6 py-3 rounded-xl font-semibold transition-colors border border-gray-700"
            >
                Qo'shilish
            </button>
        </div>
      </div>
    </div>
  </div>
  );
};


const App: React.FC = () => {
  // Auth State
  const [user, setUser] = useState<User | null>(null);

  // Router State
  const [currentPage, setCurrentPage] = useState<'login' | 'landing' | 'meeting'>('login');
  const [meetingId, setMeetingId] = useState<string | null>(null);
  
  // Media State
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null); // For P2P
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  
  // Connections State
  const [aiConnectionState, setAiConnectionState] = useState<MeetingState>(MeetingState.IDLE);
  const [isPeerConnected, setIsPeerConnected] = useState(false); // P2P State
  const [aiCaption, setAiCaption] = useState<string>(""); // Subtitles
  
  // AI Animation State
  const [aiVolume, setAiVolume] = useState(0); // 0 to 1 range
  
  // Refs
  const geminiService = useRef<GeminiLiveService | null>(null);
  const peerService = useRef<PeerService | null>(null);
  const outputAudioContext = useRef<AudioContext | null>(null);
  const audioAnalyser = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const videoIntervalRef = useRef<number | null>(null);
  const nextStartTime = useRef<number>(0);

  // Check Hash for "Join" flow on load
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#meeting/')) {
        const id = hash.split('/')[1];
        setMeetingId(id);
        // If not logged in, we need to show login first, but remember we want to join
        if (user) {
            setCurrentPage('meeting');
        } else {
            setCurrentPage('login');
        }
      } else if (user) {
        setCurrentPage('landing');
      } else {
        setCurrentPage('login');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    // Initial check handled after login or if user persists
    if (user) handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [user]);

  // Handle Login
  const handleLogin = () => {
    const mockUser: User = {
        id: 'user-' + Math.random().toString(36).substr(2, 9),
        name: 'Foydalanuvchi ' + Math.floor(Math.random() * 100),
        email: 'test@gmail.com',
        photoUrl: 'https://api.dicebear.com/9.x/avataaars/svg?seed=' + Math.random()
    };
    setUser(mockUser);
    
    // After login, check if there was a pending meeting link
    const hash = window.location.hash;
    if (hash.startsWith('#meeting/')) {
        const id = hash.split('/')[1];
        setMeetingId(id);
        setCurrentPage('meeting');
    } else {
        setCurrentPage('landing');
    }
  };

  // Initialize Media on Meeting Join
  useEffect(() => {
    if (currentPage === 'meeting') {
      initializeMediaAndConnections();
    } else {
      cleanupMedia();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage]);

  // Audio Analyzer Loop
  useEffect(() => {
    if (aiConnectionState !== MeetingState.CONNECTED) {
        setAiVolume(0);
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
            animationFrameRef.current = null;
        }
        return;
    }

    const updateVolume = () => {
        if (audioAnalyser.current) {
            const dataArray = new Uint8Array(audioAnalyser.current.frequencyBinCount);
            audioAnalyser.current.getByteFrequencyData(dataArray);
            
            // Calculate average volume
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
                sum += dataArray[i];
            }
            const average = sum / dataArray.length;
            // Normalize to 0-1 range (approximate)
            // 255 is max byte value, but speech usually hovers lower
            const normalizedVol = Math.min(1, average / 100); 
            setAiVolume(normalizedVol);
        }
        animationFrameRef.current = requestAnimationFrame(updateVolume);
    };
    
    updateVolume();

    return () => {
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }
    };
  }, [aiConnectionState]);

  const initializeMediaAndConnections = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 16000
        }
      });
      setLocalStream(stream);
      addSystemMessage("Uchrashuvga ulandingiz. Kamerangiz ishlamoqda.");

      // Setup P2P
      if (meetingId) {
          setupPeerConnection(stream, meetingId);
      }

    } catch (err) {
      console.error("Media Error:", err);
      addSystemMessage("Kamera yoki mikrofonga ruxsat berilmadi.");
    }
  };

  const setupPeerConnection = async (stream: MediaStream, roomId: string) => {
      peerService.current = new PeerService();
      
      try {
          // Attempt to join as Host (Claim ID)
          await peerService.current.init(roomId, (remoteStream) => {
              setRemoteStream(remoteStream);
              setIsPeerConnected(true);
              addSystemMessage("Mehmon ulandi!");
          });
          
          addSystemMessage("Siz mezbonsiz. Linkni ulashing.");

      } catch (err: any) {
           console.log("ID taken, joining as guest...");
           
           const myRandomId = `guest-${Math.random().toString(36).substr(2,9)}`;
           await peerService.current.init(myRandomId, (incomingStream) => {
               setRemoteStream(incomingStream);
           });

           peerService.current.setLocalStream(stream);
           peerService.current.connectToPeer(roomId, (hostStream) => {
               setRemoteStream(hostStream);
               setIsPeerConnected(true);
               addSystemMessage("Mezbon bilan bog'lanildi!");
           });
      }
  };

  const cleanupMedia = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    setRemoteStream(null);
    setIsPeerConnected(false);
    
    if (peerService.current) {
        peerService.current.destroy();
        peerService.current = null;
    }
    disconnectGemini();
  };

  const createMeeting = () => {
    const id = Math.random().toString(36).substring(2, 9);
    window.location.hash = `meeting/${id}`;
    setMeetingId(id);
    setCurrentPage('meeting');
    
    const link = `${window.location.origin}/#meeting/${id}`;
    navigator.clipboard.writeText(link);
    
    setTimeout(() => {
        alert(`Uchrashuv yaratildi!\nLink nusxalandi: ${link}\nBuni do'stingizga yuboring.`);
    }, 500);
  };

  const joinMeeting = (id: string) => {
      window.location.hash = `meeting/${id}`;
      setMeetingId(id);
      setCurrentPage('meeting');
  };

  // Chat Logic
  const addSystemMessage = (text: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender: 'system',
      text,
      timestamp: new Date()
    }]);
  };

  const handleSendMessage = (text: string) => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      sender: 'me',
      text,
      timestamp: new Date()
    }]);
  };

  // Gemini Live Logic
  const toggleGeminiConnection = async () => {
    if (aiConnectionState === MeetingState.CONNECTED || aiConnectionState === MeetingState.CONNECTING) {
        await disconnectGemini();
    } else {
        await connectGemini();
    }
  };

  const connectGemini = async () => {
    if (!localStream) return;
    
    setAiConnectionState(MeetingState.CONNECTING);
    addSystemMessage("AI (Gemini) bilan bog'lanilmoqda...");

    geminiService.current = new GeminiLiveService();
    // Use default sample rate if possible, or specify consistent one.
    // 24000 matches Gemini output, good for resampling.
    outputAudioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    // Create Analyser
    audioAnalyser.current = outputAudioContext.current.createAnalyser();
    audioAnalyser.current.fftSize = 256; // Smaller FFT size for faster reaction
    audioAnalyser.current.smoothingTimeConstant = 0.5; // Smooths the data slightly

    nextStartTime.current = 0; // Reset scheduling

    try {
      await geminiService.current.connect(localStream, {
        onOpen: () => {
            setAiConnectionState(MeetingState.CONNECTED);
          addSystemMessage("Gemini AI qo'shildi.");
          startVideoStreamingToAI();
        },
        onMessage: (text, audioData) => {
             if (audioData && outputAudioContext.current) {
                 playAudioChunk(audioData);
             }
        },
        onCaption: (text, isFinal) => {
            if (isFinal) {
                // Optionally clear or save
                if (!text) {
                     // small delay before clearing to let user read
                     setTimeout(() => setAiCaption(""), 2000);
                }
            } else {
                setAiCaption(prev => prev + text);
            }
            
            // If text is empty string specifically sent to clear (like interruption)
            if (text === "" && isFinal) {
                setAiCaption("");
            }
        },
        onError: (err) => {
            setAiConnectionState(MeetingState.ERROR);
          addSystemMessage(`AI Xatolik: ${err.message}`);
        },
        onClose: () => {
            setAiConnectionState(MeetingState.IDLE);
          addSystemMessage("AI chiqib ketdi.");
          stopVideoStreamingToAI();
          setAiCaption("");
        }
      });
    } catch (e) {
        setAiConnectionState(MeetingState.ERROR);
    }
  };

  const disconnectGemini = async () => {
    if (geminiService.current) {
        await geminiService.current.disconnect();
        geminiService.current = null;
    }
    if (outputAudioContext.current) {
        outputAudioContext.current.close();
        outputAudioContext.current = null;
    }
    stopVideoStreamingToAI();
    setAiConnectionState(MeetingState.IDLE);
    setAiCaption("");
    setAiVolume(0);
  };

  const playAudioChunk = async (arrayBuffer: ArrayBuffer) => {
    if (!outputAudioContext.current) return;
    try {
        // Decode PCM16 directly
        const audioBuffer = outputAudioContext.current.createBuffer(1, arrayBuffer.byteLength / 2, 24000);
        const channelData = audioBuffer.getChannelData(0);
        const int16Array = new Int16Array(arrayBuffer);
        
        for (let i = 0; i < int16Array.length; i++) {
            channelData[i] = int16Array[i] / 32768.0;
        }

        const source = outputAudioContext.current.createBufferSource();
        source.buffer = audioBuffer;
        
        // Connect Source -> Analyser -> Destination
        if (audioAnalyser.current) {
            source.connect(audioAnalyser.current);
            audioAnalyser.current.connect(outputAudioContext.current.destination);
        } else {
            source.connect(outputAudioContext.current.destination);
        }
        
        // Critical: Scheduling logic for smooth playback
        const currentTime = outputAudioContext.current.currentTime;
        if (nextStartTime.current < currentTime) {
            nextStartTime.current = currentTime;
        }
        
        source.start(nextStartTime.current);
        nextStartTime.current += audioBuffer.duration;

    } catch (e) {
        console.error("Audio playback error", e);
    }
  };

  const startVideoStreamingToAI = () => {
    if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const hiddenVideo = document.createElement('video');
    
    if (localStream) {
        hiddenVideo.srcObject = localStream;
        hiddenVideo.muted = true;
        hiddenVideo.play().catch(() => {});
    
        videoIntervalRef.current = window.setInterval(async () => {
            if (!geminiService.current || !ctx || hiddenVideo.readyState < 2) return;
            canvas.width = 320; 
            canvas.height = 240;
            ctx.drawImage(hiddenVideo, 0, 0, canvas.width, canvas.height);
            const base64 = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
            geminiService.current.sendVideoFrame(base64);
        }, 1000); 
    }
  };

  const stopVideoStreamingToAI = () => {
      if (videoIntervalRef.current) {
          clearInterval(videoIntervalRef.current);
          videoIntervalRef.current = null;
      }
  };

  const toggleMute = () => {
    if (localStream) {
        localStream.getAudioTracks().forEach(t => t.enabled = !t.enabled);
        setIsMuted(!isMuted);
    }
  };

  const toggleCamera = () => {
    if (localStream) {
        localStream.getVideoTracks().forEach(t => t.enabled = !t.enabled);
        setIsCameraOff(!isCameraOff);
    }
  };

  const leaveMeeting = () => {
    cleanupMedia();
    window.location.hash = '';
    setCurrentPage('landing');
  };

  if (!user || currentPage === 'login') {
      return <LoginPage onLogin={handleLogin} />;
  }

  if (currentPage === 'landing') {
    return <LandingPage onCreate={createMeeting} onJoin={joinMeeting} user={user} />;
  }

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden relative">
      <div className="flex-1 flex flex-col relative z-0">
        {/* Top Bar */}
        <div className="h-16 border-b border-gray-800 flex items-center justify-between px-6 bg-gray-900">
           <div className="flex items-center gap-2">
               <div className="w-8 h-8 rounded bg-brand-600 flex items-center justify-center font-bold">U</div>
               <span className="font-semibold text-lg hidden md:block">UzMeet</span>
               <div className="flex items-center gap-2 bg-gray-800 px-3 py-1 rounded-full border border-gray-700 ml-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                  <span className="text-xs text-gray-300 font-mono">{meetingId}</span>
                  <button 
                    onClick={() => {
                        navigator.clipboard.writeText(`${window.location.origin}/#meeting/${meetingId}`);
                        alert("Link nusxalandi!");
                    }}
                    className="ml-2 text-gray-400 hover:text-white"
                    title="Linkni nusxalash"
                  >
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 0 1-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 0 1 1.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 0 0-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 0 1-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H9.75" />
                      </svg>
                  </button>
               </div>
           </div>
           
           <div className="flex items-center gap-4">
                <button 
                  onClick={() => setIsChatOpen(!isChatOpen)}
                  className={`p-2 rounded hover:bg-gray-800 transition-colors ${isChatOpen ? 'text-brand-500' : 'text-gray-400'}`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.068.157 2.148.279 3.238.364.466.037.893.281 1.153.671L12 21l2.652-4.178c.26-.39.687-.634 1.153-.67 1.09-.086 2.17-.208 3.238-.365 1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z" />
                    </svg>
                </button>
           </div>
        </div>

        {/* Video Area */}
        <VideoGrid 
            localStream={localStream} 
            remoteStream={remoteStream}
            aiVolume={aiVolume}
            isAIConnected={aiConnectionState === MeetingState.CONNECTED}
            caption={aiCaption}
        />

        {/* Controls */}
        <MeetingControls 
           isMuted={isMuted}
           isCameraOff={isCameraOff}
           isConnected={aiConnectionState === MeetingState.CONNECTED || aiConnectionState === MeetingState.CONNECTING}
           onToggleMute={toggleMute}
           onToggleCamera={toggleCamera}
           onConnectDisconnect={toggleGeminiConnection}
           onLeave={leaveMeeting}
        />
      </div>

      {/* Chat Sidebar */}
      <ChatSidebar 
        isOpen={isChatOpen} 
        onClose={() => setIsChatOpen(false)}
        messages={messages}
        onSendMessage={handleSendMessage}
      />
    </div>
  );
};

export default App;