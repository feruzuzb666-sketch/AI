export interface Message {
  id: string;
  sender: 'me' | 'remote' | 'system';
  text: string;
  timestamp: Date;
}

export enum MeetingState {
  IDLE,
  CONNECTING,
  CONNECTED,
  ERROR
}

export interface AudioVisualizerData {
  volume: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  photoUrl: string;
}

export interface PeerConnectionState {
  isPeerConnected: boolean;
  remoteStream: MediaStream | null;
}
