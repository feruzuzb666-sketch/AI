import Peer from 'peerjs';

export class PeerService {
  private peer: Peer | null = null;
  private myStream: MediaStream | null = null;
  private call: any = null; // Peer.MediaConnection

  constructor() {}

  init(userId: string, onCallReceived: (stream: MediaStream) => void): Promise<string> {
    return new Promise((resolve, reject) => {
      // Create a peer with the specific userId so others can dial it directly
      // Note: In production, use your own TURN/STUN server or PeerServer
      this.peer = new Peer(userId, {
        debug: 2
      });

      this.peer.on('open', (id) => {
        console.log('My Peer ID is: ' + id);
        resolve(id);
      });

      this.peer.on('call', (incomingCall) => {
        console.log('Incoming call...');
        this.call = incomingCall;
        
        // Answer automatically if we have a stream ready, or wait
        if (this.myStream) {
           incomingCall.answer(this.myStream);
           incomingCall.on('stream', (remoteStream: MediaStream) => {
               console.log("Receiving remote stream (Answered)");
               onCallReceived(remoteStream);
           });
        }
      });

      this.peer.on('error', (err) => {
        console.error('Peer error:', err);
        // Sometimes ID is taken, handle retry or reject
        if (err.type === 'unavailable-id') {
             // If ID is taken, maybe we are the joiner, which is fine
             // reject(err); 
        }
      });
    });
  }

  setLocalStream(stream: MediaStream) {
    this.myStream = stream;
    // If we already have a call object (e.g. we answered but stream wasn't ready), update it?
    // PeerJS usually requires stream at answer time.
  }

  connectToPeer(peerId: string, onStreamReceived: (stream: MediaStream) => void) {
    if (!this.peer || !this.myStream) {
        console.error("Peer not initialized or local stream missing");
        return;
    }

    console.log(`Calling peer: ${peerId}`);
    const call = this.peer.call(peerId, this.myStream);
    this.call = call;

    call.on('stream', (remoteStream: MediaStream) => {
        console.log("Receiving remote stream (Caller)");
        onStreamReceived(remoteStream);
    });

    call.on('error', (err: any) => {
        console.error("Call error:", err);
    });
  }

  destroy() {
    if (this.call) {
        this.call.close();
    }
    if (this.peer) {
        this.peer.destroy();
    }
  }
}
