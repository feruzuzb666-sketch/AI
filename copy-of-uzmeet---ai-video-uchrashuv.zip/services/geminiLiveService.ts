import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { base64ToUint8Array, createPCMBlob } from '../utils/audioUtils';

// Constants
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-12-2025';
const SAMPLE_RATE_INPUT = 16000;

interface LiveSessionCallbacks {
  onOpen: () => void;
  onMessage: (text: string | null, audioData: ArrayBuffer | null) => void;
  onCaption: (text: string, isFinal: boolean) => void;
  onError: (error: Error) => void;
  onClose: () => void;
}

export class GeminiLiveService {
  private client: GoogleGenAI;
  private sessionPromise: Promise<any> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private mediaStreamSource: MediaStreamAudioSourceNode | null = null;

  constructor() {
    this.client = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async connect(stream: MediaStream, callbacks: LiveSessionCallbacks) {
    this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: SAMPLE_RATE_INPUT,
    });

    try {
      this.sessionPromise = this.client.live.connect({
        model: MODEL_NAME,
        config: {
          responseModalities: [Modality.AUDIO],
          // Enable transcription for the model's audio output
          outputAudioTranscription: {},
          systemInstruction: "You are a helpful and friendly meeting participant speaking in Uzbek. You are in a video call. Keep responses concise and conversational.",
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
        callbacks: {
          onopen: () => {
            console.log("Gemini Live Connected");
            this.startAudioStream(stream);
            callbacks.onOpen();
          },
          onmessage: (msg: LiveServerMessage) => {
            // Handle Audio
            const audioBase64 = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            let audioData: ArrayBuffer | null = null;
            if (audioBase64) {
               audioData = base64ToUint8Array(audioBase64).buffer;
               callbacks.onMessage(null, audioData);
            }

            // Handle Captions (Transcription)
            if (msg.serverContent?.outputTranscription?.text) {
                callbacks.onCaption(msg.serverContent.outputTranscription.text, false);
            }

            // Handle Turn Completion (to finalize caption or clear later)
            if (msg.serverContent?.turnComplete) {
                callbacks.onCaption("", true);
            }
            
            // Handle Interruption (User started speaking)
            if (msg.serverContent?.interrupted) {
                callbacks.onCaption("", true); // Clear captions immediately
            }
          },
          onerror: (err) => {
            console.error("Gemini Live Error:", err);
            callbacks.onError(new Error("Connection error"));
          },
          onclose: () => {
            console.log("Gemini Live Closed");
            callbacks.onClose();
          }
        }
      });
      
      await this.sessionPromise;

    } catch (e) {
      console.error("Failed to connect:", e);
      callbacks.onError(e as Error);
    }
  }

  private startAudioStream(stream: MediaStream) {
    if (!this.inputAudioContext) return;

    this.mediaStreamSource = this.inputAudioContext.createMediaStreamSource(stream);
    this.processor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

    this.processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcmBlob = createPCMBlob(inputData);
      
      if (this.sessionPromise) {
        this.sessionPromise.then(session => {
            session.sendRealtimeInput({ media: pcmBlob });
        }).catch(err => console.error("Error sending audio:", err));
      }
    };

    this.mediaStreamSource.connect(this.processor);
    this.processor.connect(this.inputAudioContext.destination);
  }

  sendVideoFrame(base64Image: string) {
    if (this.sessionPromise) {
        this.sessionPromise.then(session => {
            session.sendRealtimeInput({
                media: {
                    mimeType: 'image/jpeg',
                    data: base64Image
                }
            });
        });
    }
  }

  async disconnect() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.mediaStreamSource) {
      this.mediaStreamSource.disconnect();
      this.mediaStreamSource = null;
    }
    if (this.inputAudioContext) {
      await this.inputAudioContext.close();
      this.inputAudioContext = null;
    }
  }
}
